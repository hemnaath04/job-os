"use strict";(()=>{var Se=["data-automation-id","data-qa","data-testid","data-ui"];function q(e){let t=e.getAttribute("aria-labelledby");if(t){let c=t.split(/\s+/).map(g=>e.ownerDocument.getElementById(g)?.textContent??"").join(" ").trim();if(c)return c}let n=e.getAttribute("aria-label");if(n&&n.trim())return n.trim();let r=e.getAttribute("id");if(r){let c=e.ownerDocument.querySelector(`label[for="${D(r)}"]`),g=S(c);if(g)return g}let o=e.closest("label"),i=S(o);if(i)return i;let l=e.closest("fieldset")?.querySelector("legend"),s=S(l);if(s)return s;let d=e.closest('[role="group"], [role="radiogroup"]');if(d&&d!==e){let c=d.getAttribute("aria-label");if(c&&c.trim())return c.trim();let g=d.getAttribute("aria-labelledby");if(g){let b=g.split(/\s+/).map(v=>e.ownerDocument.getElementById(v)?.textContent??"").join(" ").trim();if(b)return b}}let a=Te(e);if(a)return a;let p=e.getAttribute("placeholder");if(p&&p.trim())return p.trim();let u=e.getAttribute("name")??r;return u?Ke(u):""}function Re(e){return e.toLowerCase().replace(/\(\s*(required|optional|mandatory)\s*\)/g," ").replace(/\brequired\b/g," ").replace(/[‘’]/g,"'").replace(/[^a-z0-9'#+/ ]+/g," ").replace(/\s+/g," ").trim()}function Ce(e){let t=e.tagName.toLowerCase();if(t==="textarea")return"textarea";if(t==="select")return"select";if(t==="input"){let o=(e.getAttribute("type")??"text").toLowerCase();return o==="file"?"file":o==="checkbox"?"checkbox":o==="radio"?"radiogroup":o==="hidden"||o==="submit"||o==="button"||o==="image"?"unsupported":"text"}let n=(e.getAttribute("role")??"").toLowerCase(),r=(e.getAttribute("aria-haspopup")??"").toLowerCase();return r==="listbox"||r==="menu"||r==="true"?"popup_select":n==="radiogroup"?"radiogroup":n==="combobox"||n==="listbox"?"popup_select":n==="checkbox"||n==="switch"?"checkbox":n==="textbox"?e.getAttribute("aria-multiline")==="true"?"textarea":"text":e.getAttribute("contenteditable")==="true"?"textarea":"unsupported"}function Le(e,t){if(e.hasAttribute("required")||e.getAttribute("aria-required")==="true")return!0;let n=e.getAttribute("id"),r=(n?e.ownerDocument.querySelector(`label[for="${D(n)}"]`):null)??e.closest("label")??e.closest("fieldset")?.querySelector("legend")??null;return r&&(r.querySelector('abbr[title="required" i], .required, [aria-hidden="true"].asterisk')||/\*\s*$/.test(r.textContent??"")||/\brequired\b/i.test(r.textContent??""))?!0:/\*\s*$/.test(t)||/\brequired\b/i.test(t)}function qe(e){if(e instanceof e.ownerDocument.defaultView.HTMLSelectElement)return Array.from(e.options).map(o=>({value:o.value,label:(o.textContent??"").trim()}));let t=e.ownerDocument,n=e.querySelectorAll('input[type="radio"]');if(n.length>0)return Array.from(n).map(o=>({value:o.getAttribute("value")??"",label:q(o).trim()}));if(e.getAttribute("type")==="radio"){let o=e.getAttribute("name");if(o)return Array.from(t.querySelectorAll(`input[type="radio"][name="${D(o)}"]`)).map(i=>({value:i.getAttribute("value")??"",label:q(i).trim()}))}let r=e.querySelectorAll('[role="option"]');return r.length>0?Array.from(r).map(o=>({value:o.getAttribute("data-value")??(o.textContent??"").trim(),label:(o.textContent??"").trim()})):[]}function De(e){for(let t of Se){let n=e.getAttribute(t);if(n&&n.trim())return n.trim()}return null}function A(e){let t=q(e),n=Ce(e);return{element:e,kind:n,label:Re(t),rawLabel:t.replace(/\s+/g," ").trim(),name:e.getAttribute("name"),id:e.getAttribute("id"),autocomplete:e.getAttribute("autocomplete"),placeholder:e.getAttribute("placeholder"),required:Le(e,t),options:qe(e),automationId:De(e)}}function S(e){if(!e)return"";let t=e.cloneNode(!0);return t.querySelectorAll("input, select, textarea, button").forEach(n=>n.remove()),(t.textContent??"").replace(/\s+/g," ").trim()}function Te(e){let t=e.parentElement;for(let n=0;t&&n<4;n+=1,t=t.parentElement){let r=t.querySelector("label, legend, [data-automation-id$='label']"),o=S(r);if(o)return o}return""}function Ke(e){return e.replace(/[_\-.[\]]+/g," ").replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/\s+/g," ").trim()}function D(e){let t=globalThis.CSS;return t?.escape?t.escape(e):e.replace(/["\\\]\[:.#$&*+,/;<=>?@^`{|}~]/g,"\\$&")}var Pe=["input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset])","textarea","select",'[role="radiogroup"]','[role="combobox"]','[contenteditable="true"]'].join(", ");function y(e){let t=new Set,n=[];for(let r of Array.from(e.querySelectorAll(Pe)))if(!Ve(r)){if(r.getAttribute("type")==="radio"){let o=r.getAttribute("name");if(o){if(t.has(o))continue;t.add(o),n.push(Oe(e,r,o));continue}}r.closest('[role="radiogroup"]')&&!r.matches('[role="radiogroup"]')||n.push(A(r))}return n}function Oe(e,t,n){let r=$e(e,n)??t,o=A(r===t?t:r);return{...o,kind:"radiogroup",element:r,name:n,required:o.required||t.hasAttribute("required")||t.getAttribute("aria-required")==="true"}}function $e(e,t){let n=Array.from(e.querySelectorAll(`input[type="radio"][name="${t.replace(/"/g,'\\"')}"]`));if(n.length===0)return null;let r=n[0].closest('fieldset, [role="radiogroup"]');if(r&&n.every(i=>r.contains(i)))return r;let o=n[0].parentElement;for(;o&&!n.every(i=>o.contains(i));)o=o.parentElement;return o}function Ve(e){return e.hasAttribute("hidden")||e.getAttribute("aria-hidden")==="true"||e.style?.display==="none"||e.style?.visibility==="hidden"?!0:e.closest("[hidden], [aria-hidden='true']")!==null}var Ne={name:"full_name",email:"email",phone:"phone",linkedin:"linkedin_url",github:"github_url",website:"portfolio_url",portfolio:"portfolio_url"},M={id:"ashby",label:"Ashby",detect({url:e,document:t}){let n=e.hostname.toLowerCase();return n==="jobs.ashbyhq.com"||n.endsWith(".ashbyhq.com")?!0:t.querySelector("[id^='_systemfield_'], [data-highlight='ashby']")!==null},formRoots(e){let t=e.querySelectorAll("form.ashby-application-form, [class*='ashby-application-form'], form");return t.length>0?Array.from(t):[e.body]},collectFields:y,fieldKeyHint(e){let t=e.id??"",n=/^_systemfield_(\w+)$/.exec(t);if(n){let r=n[1].toLowerCase();return Ne[r]??null}if(e.element.closest("[data-testid='eeoc'], [id*='eeoc'], [class*='DemographicQuestion']")){let r=e.label;if(r.includes("gender"))return"eeo_gender";if(r.includes("race")||r.includes("ethnic"))return"eeo_race";if(r.includes("hispanic")||r.includes("latino"))return"eeo_hispanic";if(r.includes("veteran"))return"eeo_veteran";if(r.includes("disability"))return"eeo_disability"}return null}};var j={id:"generic",label:"Generic form",detect(){return!1},formRoots(e){let t=Array.from(e.querySelectorAll("form"));if(t.length===0)return[e.body];let r=t.map(o=>({form:o,score:o.querySelectorAll("input:not([type=hidden]), textarea, select").length})).sort((o,i)=>i.score-o.score)[0];return r&&r.score>=3?[r.form]:t},collectFields:y};var R={first_name:"first_name",last_name:"last_name",email:"email",phone:"phone",job_application_answers_attributes_0_text_value:"linkedin_url"},Ie=["boards.greenhouse.io","job-boards.greenhouse.io","my.greenhouse.io"],H={id:"greenhouse",label:"Greenhouse",detect({url:e,document:t}){let n=e.hostname.toLowerCase();return Ie.some(r=>n===r||n.endsWith(`.${r}`))?!0:t.querySelector("#grnhse_app, #application_form, form#application-form")!==null&&t.querySelector('input[id="first_name"], input[name="job_application[first_name]"]')!==null},formRoots(e){let t=e.querySelectorAll("#application_form, form#application-form, #grnhse_app form, form[action*='greenhouse']");return t.length>0?Array.from(t):Array.from(e.querySelectorAll("form"))},collectFields:y,fieldKeyHint(e){let t=e.id??"";if(t in R)return R[t]??null;let n=e.name??"",r=/^job_application\[(\w+)\]$/.exec(n);if(r){let o=r[1];if(o in R)return R[o]??null}if(e.element.closest("#demographic_questions, [data-testid='eeoc-section']")){if(t.includes("gender"))return"eeo_gender";if(t.includes("race")||t.includes("ethnic"))return"eeo_race";if(t.includes("hispanic"))return"eeo_hispanic";if(t.includes("veteran"))return"eeo_veteran";if(t.includes("disability"))return"eeo_disability"}return null}};var B={name:"full_name",email:"email",phone:"phone",org:"current_company",company:"current_company",location:"city"},ze={linkedin:"linkedin_url",github:"github_url",portfolio:"portfolio_url",twitter:"other_url",other:"other_url"},G={id:"lever",label:"Lever",detect({url:e,document:t}){let n=e.hostname.toLowerCase();return n==="jobs.lever.co"||n.endsWith(".lever.co")?!0:t.querySelector("form[action*='lever.co'], .application-form[data-qa]")!==null},formRoots(e){let t=e.querySelectorAll("form.application-form, form[action*='lever.co'], div.application-form");return t.length>0?Array.from(t):Array.from(e.querySelectorAll("form"))},collectFields:y,fieldKeyHint(e){let t=e.name??"";if(t in B)return B[t]??null;let n=/^urls\[([^\]]+)\]$/.exec(t);if(n){let o=n[1].toLowerCase();return ze[o]??"other_url"}let r=/^eeo\[([^\]]+)\]$/.exec(t);if(r){let o=r[1].toLowerCase();return o.includes("signature")?null:o.includes("gender")?"eeo_gender":o.includes("race")||o.includes("ethnic")?"eeo_race":o.includes("veteran")?"eeo_veteran":o.includes("disability")?"eeo_disability":null}return null}};var _={firstName:"first_name",lastName:"last_name",email:"email",phoneNumber:"phone",phone:"phone",city:"city",country:"country",region:"state",postalCode:"postal_code",street:"address_line1",linkedinProfileUrl:"linkedin_url",web:"portfolio_url"},Y={id:"smartrecruiters",label:"SmartRecruiters",detect({url:e,document:t}){return e.hostname.toLowerCase().endsWith("smartrecruiters.com")?!0:t.querySelector("[data-test='application-form'], #sr-application-form")!==null},formRoots(e){let t=e.querySelectorAll("[data-test='application-form'], #sr-application-form, form[action*='smartrecruiters']");return t.length>0?Array.from(t):Array.from(e.querySelectorAll("form"))},collectFields:y,fieldKeyHint(e){let t=e.name??"";if(t in _)return _[t]??null;let n=e.id??"";if(n in _)return _[n]??null;let r=e.automationId??"",o=/^field-(\w+)$/.exec(r);if(o){let i=o[1];if(i in _)return _[i]??null}return null}};var Me=[["legalNameSection_firstName","first_name"],["legalNameSection_lastName","last_name"],["legalNameSection_preferredName","preferred_name"],["preferredNameSection_firstName","preferred_name"],["addressSection_addressLine1","address_line1"],["addressSection_addressLine2","address_line2"],["addressSection_city","city"],["addressSection_countryRegion","state"],["addressSection_regionSubdivision1","state"],["addressSection_postalCode","postal_code"],["countryDropdown","country"],["country","country"],["email","email"],["phone-number","phone"],["phoneNumber","phone"],["jobTitle","current_title"],["company","current_company"],["schoolItem","school"],["school","school"],["degree","degree"],["field-of-study","field_of_study"],["fieldOfStudy","field_of_study"],["gpa","gpa"],["linkedinQuestion","linkedin_url"],["linkedIn","linkedin_url"]],je=/^dateSection(Month|Day|Year)-(input|display)$/,U={id:"workday",label:"Workday",detect({url:e,document:t}){let n=e.hostname.toLowerCase();return n.endsWith("myworkdayjobs.com")||n.endsWith("myworkdaysite.com")||n.endsWith("workday.com")?!0:t.querySelector("[data-automation-id='legalNameSection_firstName']")!==null},formRoots(e){let t=e.querySelectorAll("[data-automation-id='applyFlowPage'], [data-automation-id='jobApplication'], form");return t.length>0?Array.from(t):[e.body]},collectFields(e){let t=y(e),n=new Set(t.map(o=>o.element)),r=e.querySelectorAll('button[aria-haspopup="listbox"], button[aria-haspopup="menu"], [role="combobox"]');for(let o of Array.from(r)){if(n.has(o)||o.closest("[hidden], [aria-hidden='true']"))continue;let i=A(o);t.push({...i,kind:"popup_select"})}return t},fieldKeyHint(e){let t=e.automationId??"";if(!t||je.test(t))return null;for(let[n,r]of Me)if(t===n||t.endsWith(`--${n}`)||t.endsWith(`_${n}`))return r;if(/selfIdentif|voluntaryDisclosure|veteranStatus|disability/i.test(t)){if(/gender/i.test(t))return"eeo_gender";if(/ethnic|race/i.test(t))return"eeo_race";if(/hispanic|latino/i.test(t))return"eeo_hispanic";if(/veteran/i.test(t))return"eeo_veteran";if(/disability/i.test(t))return"eeo_disability"}return null}};var He=[U,H,G,M,Y];function W(e){for(let t of He)try{if(t.detect(e))return t}catch{continue}return j}function Q(e,t){let n=new Set,r=[];for(let o of e.formRoots(t))for(let i of e.collectFields(o))n.has(i.element)||(n.add(i.element),r.push(i));return r}var X=/\b(submit|apply now|apply for this job|send application|finish|complete application|i'?m done)\b/i,Be=new Set(["bottom-navigation-next-button","wd-CommandButton_uic_okButton","quickApplySubmitButton","btn-submit"]),Ge=/^(select one|select\.\.\.|select|choose one|choose|please select|-+|)$/i,w=class extends Error{constructor(t){super(`refused to click a submit control: ${t}`),this.name="SubmitRefusedError"}};function Z(e){let t=e.tagName.toLowerCase(),n=(e.getAttribute("type")??"").toLowerCase();if(t==="input"&&(n==="submit"||n==="image")||t==="button"&&(n===""||n==="submit"))return!0;let r=e.getAttribute("data-automation-id")??e.getAttribute("data-qa")??"";if(Be.has(r))return!0;let o=`${e.textContent??""} ${e.getAttribute("aria-label")??""} ${e.getAttribute("value")??""}`;if(X.test(o))return!0;let i=e.closest('button, input[type="submit"], [role="button"]');if(i&&i!==e){let l=`${i.textContent??""} ${i.getAttribute("aria-label")??""}`;if(X.test(l))return!0}return!1}function K(e){if(Z(e))throw new w(oe(e));e.click()}function J(e,t){let n=e,r=e.tagName.toLowerCase()==="textarea"?e.ownerDocument.defaultView?.HTMLTextAreaElement?.prototype:e.ownerDocument.defaultView?.HTMLInputElement?.prototype,o=r?Object.getOwnPropertyDescriptor(r,"value")?.set:void 0;return o?o.call(n,t):n.value=t,h(e,"input"),h(e,"change"),F(e)===t}function ee(e,t){let n=e.ownerDocument.defaultView;if(!n||!(e instanceof n.HTMLSelectElement)||!Array.from(e.options).find(i=>i.value===t))return!1;let o=Object.getOwnPropertyDescriptor(n.HTMLSelectElement.prototype,"value")?.set;return o?o.call(e,t):e.value=t,h(e,"input"),h(e,"change"),e.value===t}function te(e,t){let r=e.ownerDocument.defaultView;if(!r)return!1;let o=Array.from(e.querySelectorAll('input[type="radio"]')),l=(o.length>0?o:We(e)).find(s=>s.getAttribute("value")===t);return l?(K(l),l instanceof r.HTMLInputElement&&!l.checked&&(l.checked=!0,h(l,"input"),h(l,"change")),l instanceof r.HTMLInputElement?l.checked:!1):!1}function ne(e,t){let n=e.ownerDocument.defaultView;return!n||!(e instanceof n.HTMLInputElement)?!1:e.checked===t?!0:(K(e),e.checked!==t&&(e.checked=t,h(e,"input"),h(e,"change")),e.checked===t)}async function re(e,t,n){if(Z(e))throw new w(oe(e));e.click();let r=await Ye(e);if(!r)return T(e),null;let o=Array.from(r.querySelectorAll('[role="option"], li')),i=o.map(a=>({value:a.getAttribute("data-value")??a.getAttribute("value")??(a.textContent??"").trim(),label:(a.textContent??"").trim()})),l=n(i,t);if(!l)return T(e),null;let s=i.findIndex(a=>a.value===l.value&&a.label===l.label),d=s>=0?o[s]:void 0;return d?(K(d),l.label):(T(e),null)}async function Ye(e){let t=e.ownerDocument,n=e.getAttribute("aria-controls");for(let r=0;r<20;r+=1){let o=n?t.getElementById(n):null;if(o&&o.querySelector('[role="option"], li'))return o;let i=t.querySelector('[role="listbox"]:not([hidden]), [role="menu"]:not([hidden])');if(i&&i.querySelector('[role="option"], li'))return i;await Ue(25)}return null}function T(e){let t=e.ownerDocument.defaultView;t&&e.dispatchEvent(new t.KeyboardEvent("keydown",{key:"Escape",bubbles:!0,cancelable:!0}))}function Ue(e){return new Promise(t=>setTimeout(t,e))}function F(e){let t=e.ownerDocument.defaultView;if(!t)return"";if(e instanceof t.HTMLInputElement)return e.type==="checkbox"||e.type==="radio"?e.checked?e.value:"":e.type==="file"?e.files&&e.files.length>0?"file":"":e.value;if(e instanceof t.HTMLTextAreaElement||e instanceof t.HTMLSelectElement)return e.value;if(e.getAttribute("contenteditable")==="true")return e.textContent??"";let n=(e.getAttribute("aria-haspopup")??"").toLowerCase(),r=(e.getAttribute("role")??"").toLowerCase();if(n==="listbox"||n==="menu"||r==="combobox"||r==="listbox"){let i=(e.textContent??"").replace(/\s+/g," ").trim();return Ge.test(i)?"":i}let o=e.querySelector('input[type="radio"]:checked, input[type="checkbox"]:checked');return o?o.getAttribute("value")??"on":""}function We(e){let t=e.getAttribute("name");return t?Array.from(e.ownerDocument.querySelectorAll(`input[type="radio"][name="${t.replace(/"/g,'\\"')}"]`)):[]}function h(e,t){let n=e.ownerDocument.defaultView;n&&e.dispatchEvent(new n.Event(t,{bubbles:!0,cancelable:!1}))}function oe(e){let t=e.getAttribute("aria-label")??(e.textContent??"").trim().slice(0,40);return`<${e.tagName.toLowerCase()}> ${t}`}var Qe={"given-name":"first_name","family-name":"last_name",name:"full_name",nickname:"preferred_name",email:"email",tel:"phone","tel-national":"phone","street-address":"address_line1","address-line1":"address_line1","address-line2":"address_line2","address-level2":"city","address-level1":"state","postal-code":"postal_code",country:"country","country-name":"country",organization:"current_company","organization-title":"current_title",url:"portfolio_url"},Xe=[["first_name",["first name","given name","forename","legal first name","first"]],["last_name",["last name","family name","surname","legal last name","last"]],["full_name",["full name","name","your name","legal name","full legal name","candidate name"]],["preferred_name",["preferred name","nickname","preferred first name","goes by"]],["email",["email","e mail","email address","e mail address","your email","work email","personal email"]],["phone",["phone","phone number","mobile","mobile number","mobile phone","telephone","cell","cell phone","contact number","primary phone"]],["address_line1",["address","street address","address line 1","address 1","street","mailing address","home address"]],["address_line2",["address line 2","address 2","apt suite","apartment","unit","suite"]],["city",["city","town","city town","city of residence"]],["state",["state","province","region","state province","state region","county"]],["postal_code",["zip","zip code","postal code","postcode","zip postal code"]],["country",["country","country of residence","country region"]],["linkedin_url",["linkedin","linkedin url","linkedin profile","linkedin profile url","linkedin link"]],["github_url",["github","github url","github profile","github link","git hub"]],["portfolio_url",["portfolio","portfolio url","website","personal website","portfolio site","personal site","portfolio link"]],["other_url",["other website","other url","other link","additional website"]],["school",["school","university","college","institution","school name","university name"]],["degree",["degree","degree type","level of education","highest degree","education level"]],["field_of_study",["field of study","major","discipline","area of study","concentration","course of study"]],["education_start",["education start date","school start date"]],["education_end",["graduation date","education end date","expected graduation","school end date","graduation year"]],["gpa",["gpa","grade point average","cumulative gpa","gpa score"]],["current_company",["current company","company","employer","current employer","most recent company","current organization","most recent employer"]],["current_title",["current title","job title","title","current job title","current role","most recent title","position","current position"]],["work_start",["employment start date","work start date","start date"]],["work_end",["employment end date","work end date","end date"]]],Ze=[["linkedin_url",["linkedin"]],["github_url",["github"]],["email",["email address"]],["phone",["phone number","mobile number"]],["postal_code",["zip code","postal code"]],["gpa",["grade point average"]],["field_of_study",["field of study"]],["school",["name of school","name of university","which university","which school"]],["work_authorized",["legally authorized to work","authorized to work","legally eligible to work","work authorization","right to work"]],["requires_sponsorship",["require sponsorship","requires sponsorship","need sponsorship","visa sponsorship","sponsorship now or in the future","immigration sponsorship"]],["eeo_gender",["gender"]],["eeo_race",["race","ethnicity","racial"]],["eeo_hispanic",["hispanic","latino"]],["eeo_veteran",["veteran","military service","protected veteran"]],["eeo_disability",["disability","disabled"]]],Je=["why do you","why are you","why would you","tell us","tell me","describe","please provide an example","provide an example","give an example","in your own words","what makes you","what interests you","how did you hear","how would you","what are you looking for","cover letter","anything else","additional information","elaborate","explain","walk us through","share a time","exceptional ability"],et=new Set(["address_line1","address_line2"]),ie=Object.freeze({key:null,refusal:"unrecognized"}),tt=Object.freeze({key:null,refusal:"essay"}),ae=Object.freeze({key:null,refusal:"ambiguous"});function le(e,t){if(P(e))return tt;if(t)return{key:t,refusal:null};let n=(e.autocomplete??"").toLowerCase().trim();if(n&&n!=="off"&&n!=="on"){let s=n.split(/\s+/).pop()??"",d=Qe[s];if(d)return{key:d,refusal:null}}let r=(e.element.getAttribute("type")??"").toLowerCase();if(r==="email")return{key:"email",refusal:null};if(r==="tel")return{key:"phone",refusal:null};let o=e.label;if(!o)return ie;let i=se(o);if(i.length===1)return{key:i[0],refusal:null};if(i.length>1)return ae;let l=nt(o);return l.length===1?{key:l[0],refusal:null}:l.length>1?ae:ie}function P(e){let t=e.label;if(Je.some(n=>t.includes(n)))return!0;if(e.kind==="textarea"){let n=se(t),r=n.length===1?n[0]:null;if(!r||!et.has(r))return!0}return!!(t.length>80&&e.rawLabel.trimEnd().endsWith("?"))}function se(e){let t=[];for(let[n,r]of Xe)r.includes(e)&&t.push(n);return t}function nt(e){let t=[];for(let[n,r]of Ze)r.some(o=>e.includes(o))&&t.push(n);return t.includes("work_authorized")&&t.includes("requires_sponsorship")?["work_authorized","requires_sponsorship"]:t.includes("eeo_hispanic")&&t.includes("eeo_race")?["eeo_hispanic"]:t}var rt=Object.freeze({facts:Object.freeze([]),draftsDropped:0});function de(e){if(!Array.isArray(e))return rt;let t=[],n=0;for(let r of e){if(typeof r!="object"||r===null)continue;if(r.verified!==!0){n+=1;continue}let o=x(r.id),i=x(r.kind),l=x(r.title);o===null||i===null||l===null||t.push(Object.freeze({id:o,kind:i,title:l,org:x(r.org),startDate:x(r.start_date),endDate:x(r.end_date),location:x(r.location),payload:Object.freeze(typeof r.payload=="object"&&r.payload!==null&&!Array.isArray(r.payload)?{...r.payload}:{})}))}return Object.freeze({facts:Object.freeze(t),draftsDropped:n})}function ot(e,t){return e.facts.filter(n=>n.kind===t).slice().sort(it)}function k(e,t){return ot(e,t)[0]??null}function it(e,t){let n=e.endDate===null,r=t.endDate===null;if(n!==r)return n?-1:1;let o=e.endDate??"",i=t.endDate??"";return o!==i?i.localeCompare(o):(t.startDate??"").localeCompare(e.startDate??"")}function x(e){if(typeof e!="string")return null;let t=e.trim();return t===""?null:t}var ce=Symbol.for("job-os.sourced-value");function f(e,t,n){let r=fe(n);if(r===null)return null;let o={factId:e.id,kind:e.kind,factLabel:O(e),attribute:t};return $(r,o)}function C(e,t,n,r){let o=fe(n),i=r.trim();return o===null||i===""?null:(at(o,i),$(i,{factId:e.id,kind:e.kind,factLabel:O(e),attribute:t}))}function E(e,t,n,r){if(typeof n!="string")return null;let o=/^(\d{4})-(\d{2})-(\d{2})$/.exec(n.trim());if(!o)return null;let[,i,l,s]=o,d=r==="iso"?n.trim():r==="yyyy"?i:r==="mm/yyyy"?`${l}/${i}`:`${l}/${s}/${i}`;return $(d,{factId:e.id,kind:e.kind,factLabel:O(e),attribute:r==="iso"?t:`${t} (${n.trim()} as ${r})`})}function at(e,t){let n=ue(e).toLowerCase(),r=ue(t).toLowerCase();if(!n.includes(r))throw new Error(`provenance violation: "${lt(t)}" is not verbatim in its source fact`)}function pe(e){if(typeof e!="object"||e===null)return!1;let t=e;if(t[ce]!==!0||typeof t.value!="string"||t.value==="")return!1;let n=t.citation;return typeof n=="object"&&n!==null&&typeof n.factId=="string"&&n.factId!==""&&typeof n.attribute=="string"}function O(e){return e.org&&e.org!==e.title?`${e.title} at ${e.org}`:e.title}function $(e,t){let n={value:e,citation:t};return Object.defineProperty(n,ce,{value:!0,enumerable:!1,writable:!1,configurable:!1}),Object.freeze(n)}function fe(e){if(typeof e=="string"){let t=e.trim();return t===""?null:t}return typeof e=="number"&&Number.isFinite(e)?String(e):typeof e=="boolean"?e?"Yes":"No":null}function ue(e){return e.replace(/\s+/g," ").trim()}function lt(e){return e.length<=3?"***":`${e.slice(0,2)}***(${e.length})`}var st=["first_name","last_name","full_name","preferred_name","email","phone","address_line1","address_line2","city","state","postal_code","country","linkedin_url","github_url","portfolio_url","other_url","school","degree","field_of_study","education_start","education_end","gpa","current_company","current_title","work_start","work_end","work_authorized","requires_sponsorship","eeo_gender","eeo_race","eeo_hispanic","eeo_veteran","eeo_disability"],Jt=new Set(st);var me=new Set(["eeo_gender","eeo_race","eeo_hispanic","eeo_veteran","eeo_disability"]);function ye(e,t={}){let n=new Map,r=(a,p)=>{p&&!n.has(a)&&n.set(a,p)},o=k(e,"contact");if(o){let a=o.payload,p=typeof a.name=="string"?a.name:o.title;r("full_name",f(o,"payload.name",p));let u=p.trim().split(/\s+/);u.length>=2?(r("first_name",C(o,"payload.name",p,u[0])),r("last_name",C(o,"payload.name",p,u[u.length-1]))):u.length===1&&r("first_name",C(o,"payload.name",p,u[0])),r("email",f(o,"payload.email",a.email)),r("phone",f(o,"payload.phone",a.phone)),r("address_line1",f(o,"payload.address",a.address)),r("city",f(o,"payload.city",a.city)),r("state",f(o,"payload.region",a.region)),r("postal_code",f(o,"payload.postalCode",a.postalCode)),r("country",f(o,"payload.countryCode",a.countryCode)),r("portfolio_url",f(o,"payload.url",a.url));let c=dt(a.profiles)?a.profiles:{};r("linkedin_url",f(o,"payload.profiles.linkedin",c.linkedin)),r("github_url",f(o,"payload.profiles.github",c.github))}let i=k(e,"education");if(i){let a=i.payload;r("school",f(i,"org",i.org)),r("degree",f(i,"payload.studyType",a.studyType)),r("field_of_study",f(i,"payload.area",a.area)),r("gpa",f(i,"payload.score",a.score)),r("education_start",E(i,"start_date",i.startDate,"mm/yyyy")),r("education_end",E(i,"end_date",i.endDate,"mm/yyyy"))}let l=k(e,"experience");l&&(r("current_company",f(l,"org",l.org)),r("current_title",f(l,"title",l.title)),r("work_start",E(l,"start_date",l.startDate,"mm/yyyy")),r("work_end",E(l,"end_date",l.endDate,"mm/yyyy")));let s=k(e,"authorization");if(s){let a=s.payload;r("work_authorized",f(s,"payload.work_authorized",a.work_authorized)),r("requires_sponsorship",f(s,"payload.requires_sponsorship",a.requires_sponsorship))}let d=k(e,"eeo");if(d){let a=d.payload,p=[["eeo_gender","gender"],["eeo_race","race"],["eeo_hispanic","hispanic"],["eeo_veteran","veteran"],["eeo_disability","disability"]];for(let[u,c]of p)t[u]===!0&&r(u,f(d,`payload.${c}`,a[c]))}return n}function ge(e,t){return me.has(e)&&t[e]!==!0}function dt(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function be(e){let{adapter:t,fields:n,values:r,consent:o}=e,i=e.disabledKeys??new Set,l=[],s=[],d=(a,p,u,c)=>{s.push({field:a,key:p,reason:u,detail:c})};for(let a of n){if(a.kind==="unsupported"){d(a,null,"unsupported_control","This control is not one the extension can fill.");continue}if(a.kind==="file"){d(a,null,"unsupported_control","Attach this file yourself. The extension does not upload documents.");continue}let p=t.fieldKeyHint?.(a)??null,{key:u,refusal:c}=le(a,p);if(u===null){d(a,null,c==="essay"?"free_text_answer":"unrecognized_question",c==="essay"?"Free-text question. The extension never writes an answer it cannot quote from your profile.":c==="ambiguous"?"This question could mean more than one profile field, so it was left for you.":"No profile field matches this question.");continue}if(P(a)){d(a,u,"free_text_answer","Free-text question. Left blank on purpose.");continue}if(i.has(u)){d(a,u,"user_disabled","You switched this field off for this run.");continue}if(ge(u,o)){d(a,u,"eeo_not_opted_in","Demographic question. Blank unless you opt this specific field in.");continue}if(F(a.element).trim()!==""&&e.overwriteExisting!==!0){d(a,u,"already_filled","Already has a value, so it was left alone.");continue}let b=r.get(u);if(!b){d(a,u,"no_verified_fact","Your profile has no verified fact for this. Add one and it will fill next time.");continue}if(a.kind==="select"||a.kind==="radiogroup"||a.kind==="checkbox"){let v=N(a.options,b.value);if(!v){d(a,u,"no_matching_option",`None of this menu's choices match "${b.value}" exactly, so nothing was selected.`);continue}l.push({field:a,key:u,sourced:b,option:v});continue}l.push({field:a,key:u,sourced:b,option:null})}return{ats:t.id,fills:l,skips:s}}function N(e,t){let n=t.trim();if(n==="")return null;let r=e.find(a=>a.value===n);if(r)return r;let o=e.find(a=>a.label===n);if(o)return o;let i=n.toLowerCase(),l=e.filter(a=>a.value.toLowerCase()===i||a.label.toLowerCase()===i);if(l.length===1)return l[0];let s=V(n);if(s==="")return null;let d=e.filter(a=>V(a.value)===s||V(a.label)===s);return d.length===1?d[0]:null}function V(e){return e.toLowerCase().replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim()}async function he(e,t){let n=[],r=[],o=[...e.skips];for(let i of e.fills){if(!pe(i.sourced)){o.push({field:i.field,key:i.key,reason:"no_verified_fact",detail:"Value failed its provenance check at write time and was discarded."});continue}let l=!1;try{l=await ut(i)}catch(s){if(!(s instanceof w))throw s;l=!1}l?n.push(i):i.field.kind==="popup_select"?o.push({field:i.field,key:i.key,reason:"no_matching_option",detail:`This menu offered no exact match for "${i.sourced.value}", so nothing was selected.`}):r.push(i)}return{ats:e.ats,filled:n,failed:r,skipped:o,requiredGaps:ct(t)}}async function ut(e){let{field:t,option:n,sourced:r}=e;switch(t.kind){case"text":case"textarea":return J(t.element,r.value);case"select":return n?ee(t.element,n.value):!1;case"popup_select":return await re(t.element,r.value,N)!==null;case"radiogroup":return n?te(t.element,n.value):!1;case"checkbox":return ne(t.element,pt(r.value));default:return!1}}function ct(e){let t=[];for(let n of e)n.required&&n.kind!=="unsupported"&&F(n.element).trim()===""&&t.push({field:n,rawLabel:n.rawLabel||"(unlabelled field)",kind:n.kind});return t}function pt(e){return/^(yes|y|true|1|i agree|agree|confirmed)$/i.test(e.trim())}var xe=`
:host {
  all: initial;
  --bg: #F1EFE3;
  --surface-1: #FFFFFF;
  --surface-2: #F7F5EB;
  --surface-3: #EFECDD;
  --border: #E5E1D1;
  --border-strong: #D8D3C0;
  --text: #2A2530;
  --text-muted: #635C68;
  --text-dim: #837B6E;
  --accent: #FFE787;
  --accent-soft: #FBF1CE;
  --accent-border: #E9C64A;
  --accent-ink: #8A6D12;
  --on-accent: #221F0E;
  --mint-ink: #3E6E4C;
  --amber-ink: #865C15;
  --rose: #C0555F;
  --rose-ink: #A14750;
  --mauve: #7C6C77;
  --radius-card: 1rem;
  --radius-control: 0.7rem;
  --radius-nested: 0.375rem;
  --ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --dur: 190ms;

  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 2147483647;
  font-family: "Manrope", "Avenir Next", ui-sans-serif, system-ui, sans-serif;
  -webkit-font-smoothing: antialiased;
}

* { box-sizing: border-box; }

.panel {
  width: 380px;
  max-height: calc(100vh - 32px);
  display: flex;
  flex-direction: column;
  background: var(--bg);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: var(--radius-card);
  box-shadow: 0 1px 2px rgba(60, 50, 40, 0.04), 0 12px 30px -18px rgba(60, 50, 40, 0.22);
  overflow: hidden;
  animation: enter var(--dur) var(--ease-out) both;
}

@keyframes enter {
  from { opacity: 0; transform: translateY(-6px) scale(0.99); }
  to { opacity: 1; transform: none; }
}

@media (prefers-reduced-motion: reduce) {
  .panel { animation: none; }
}

header {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 14px 14px 12px;
  background: var(--surface-1);
  border-bottom: 1px solid var(--border);
}

.title { flex: 1; min-width: 0; }

h1 {
  margin: 0;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: -0.01em;
}

.subtitle {
  margin: 2px 0 0;
  font-size: 12px;
  color: var(--text-muted);
}

.close {
  appearance: none;
  border: 1px solid var(--border);
  background: var(--surface-2);
  color: var(--text-muted);
  width: 26px;
  height: 26px;
  border-radius: var(--radius-nested);
  cursor: pointer;
  font-size: 15px;
  line-height: 1;
  transition: background var(--dur) var(--ease-out), color var(--dur) var(--ease-out);
}
.close:hover { background: var(--surface-3); color: var(--text); }
.close:focus-visible { outline: 2px solid var(--accent-border); outline-offset: 2px; }

.body {
  overflow-y: auto;
  padding: 12px 14px 14px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

section {
  background: var(--surface-1);
  border: 1px solid var(--border);
  border-radius: var(--radius-control);
  overflow: hidden;
}

section.alarm {
  border-color: var(--rose);
  box-shadow: 0 0 0 3px rgba(192, 85, 95, 0.12);
}

.section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.01em;
  background: var(--surface-2);
  border-bottom: 1px solid var(--border);
}

section.alarm .section-head {
  background: rgba(192, 85, 95, 0.10);
  color: var(--rose-ink);
  border-bottom-color: rgba(192, 85, 95, 0.25);
}

.count {
  margin-left: auto;
  font-variant-numeric: tabular-nums;
  font-weight: 600;
  color: var(--text-dim);
}
section.alarm .count { color: var(--rose-ink); }

.rows { margin: 0; padding: 0; list-style: none; }

.rows li {
  padding: 9px 12px;
  border-bottom: 1px solid var(--border);
  font-size: 12px;
  line-height: 1.45;
}
.rows li:last-child { border-bottom: none; }

.field-label {
  font-weight: 600;
  color: var(--text);
  overflow-wrap: anywhere;
}

.value {
  display: block;
  margin-top: 2px;
  font-family: "Geist Mono", ui-monospace, monospace;
  font-size: 11.5px;
  color: var(--accent-ink);
  background: var(--accent-soft);
  border: 1px solid rgba(233, 198, 74, 0.4);
  border-radius: var(--radius-nested);
  padding: 3px 6px;
  overflow-wrap: anywhere;
}

.source {
  display: block;
  margin-top: 4px;
  font-size: 11px;
  color: var(--text-dim);
  overflow-wrap: anywhere;
}
.source b { font-weight: 600; color: var(--text-muted); }

.reason {
  display: block;
  margin-top: 2px;
  font-size: 11.5px;
  color: var(--text-muted);
}

.tag {
  display: inline-block;
  margin-top: 4px;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 2px 6px;
  border-radius: 999px;
  background: var(--surface-3);
  color: var(--text-dim);
}
.tag.blocked { background: rgba(134, 92, 21, 0.12); color: var(--amber-ink); }
.tag.essay { background: rgba(124, 108, 119, 0.14); color: var(--mauve); }

.note {
  margin: 0;
  padding: 10px 12px;
  font-size: 11.5px;
  color: var(--text-muted);
  background: var(--surface-2);
}

footer {
  padding: 11px 14px;
  background: var(--surface-1);
  border-top: 1px solid var(--border);
  font-size: 11.5px;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  gap: 8px;
}

.pledge {
  font-weight: 600;
  color: var(--accent-ink);
}

.empty {
  padding: 12px;
  font-size: 12px;
  color: var(--text-dim);
}
`;var _e="job-os-autofill-panel",ft={free_text_answer:"Free-text questions, never answered",unrecognized_question:"No matching profile field",no_verified_fact:"Nothing verified to say",eeo_not_opted_in:"Demographic questions, off by default",no_matching_option:"No exact option match",unsupported_control:"Needs you to do it",already_filled:"Already had a value",user_disabled:"You switched these off"},mt=["free_text_answer","no_verified_fact","eeo_not_opted_in","no_matching_option","unrecognized_question","unsupported_control","user_disabled","already_filled"];function we(e,t,n){e.getElementById(_e)?.remove();let r=e.createElement("div");r.id=_e;let o=r.attachShadow({mode:"open"}),i=e.createElement("style");i.textContent=xe,o.append(i);let l=m(e,"div","panel");l.setAttribute("role","dialog"),l.setAttribute("aria-label","job.os autofill review"),l.append(yt(e,t,n,r));let s=m(e,"div","body");t.requiredGaps.length>0&&s.append(gt(e,t.requiredGaps)),t.filled.length>0&&s.append(bt(e,t.filled)),t.failed.length>0&&s.append(ht(e,t.failed));let d=xt(e,t.skipped);for(let a of d)s.append(a);if(t.filled.length===0&&t.skipped.length===0){let a=m(e,"div","empty");a.textContent="No application fields were found on this page.",s.append(a)}l.append(s),l.append(_t(e)),o.append(l),e.body.append(r)}function yt(e,t,n,r){let o=e.createElement("header"),i=m(e,"div","title"),l=e.createElement("h1");l.textContent="Filled from your verified profile",i.append(l);let s=m(e,"p","subtitle"),d=t.ats==="generic"?"Unrecognised form":n;s.textContent=`${d}. ${wt(t.filled.length,"field")} filled, ${t.skipped.length} left blank.`,i.append(s),o.append(i);let a=e.createElement("button");return a.className="close",a.type="button",a.setAttribute("aria-label","Close the review panel"),a.textContent="\xD7",a.addEventListener("click",()=>r.remove()),o.append(a),o}function gt(e,t){let n=m(e,"section","alarm");n.append(L(e,"Required and still empty",t.length));let r=m(e,"p","note");r.textContent="Fill these in yourself before you submit. Applications that arrive with required answers missing are usually rejected automatically, and you are not told why.",n.append(r);let o=e.createElement("ul");o.className="rows";for(let i of t){let l=e.createElement("li"),s=m(e,"span","field-label");s.textContent=i.rawLabel,l.append(s),o.append(l)}return n.append(o),n}function bt(e,t){let n=e.createElement("section");n.append(L(e,"Filled, with the fact behind each one",t.length));let r=e.createElement("ul");r.className="rows";for(let o of t){let i=e.createElement("li"),l=m(e,"span","field-label");l.textContent=o.field.rawLabel||o.key,i.append(l);let s=m(e,"span","value");s.textContent=o.option?o.option.label||o.option.value:o.sourced.value,i.append(s);let d=m(e,"span","source"),a=e.createElement("b");a.textContent=o.sourced.citation.factLabel,d.append("From ",a,` (${o.sourced.citation.kind}, ${o.sourced.citation.attribute})`),i.append(d),r.append(i)}return n.append(r),n}function ht(e,t){let n=m(e,"section","alarm");n.append(L(e,"Tried to fill but the page rejected it",t.length));let r=m(e,"p","note");r.textContent="These are still empty. Type them in yourself.",n.append(r);let o=e.createElement("ul");o.className="rows";for(let i of t){let l=e.createElement("li"),s=m(e,"span","field-label");s.textContent=i.field.rawLabel||i.key,l.append(s),o.append(l)}return n.append(o),n}function xt(e,t){let n=new Map;for(let o of t){let i=n.get(o.reason);i?i.push(o):n.set(o.reason,[o])}let r=[];for(let o of mt){let i=n.get(o);if(!i||i.length===0)continue;let l=e.createElement("section");l.append(L(e,ft[o],i.length));let s=e.createElement("ul");s.className="rows";for(let d of i){let a=e.createElement("li"),p=m(e,"span","field-label");p.textContent=d.field.rawLabel||d.key||"(unlabelled field)",a.append(p);let u=m(e,"span","reason");if(u.textContent=d.detail,a.append(u),o==="free_text_answer"){let c=m(e,"span","tag essay");c.textContent="Left for you",a.append(c)}else if(o==="eeo_not_opted_in"){let c=m(e,"span","tag blocked");c.textContent="Opt in per field",a.append(c)}s.append(a)}l.append(s),r.push(l)}return r}function _t(e){let t=e.createElement("footer"),n=m(e,"span","pledge");return n.textContent="This extension never submits.",t.append(n," Read everything above, then send the application yourself."),t}function L(e,t,n){let r=m(e,"div","section-head");r.append(t);let o=m(e,"span","count");return o.textContent=String(n),r.append(o),r}function m(e,t,n){let r=e.createElement(t);return r.className=n,r}function wt(e,t){return`${e} ${t}${e===1?"":"s"}`}function ke(e){if(typeof e!="object"||e===null)return null;let t=e;switch(t.type){case"status":return{type:"status"};case"fill":return typeof t.tabId=="number"?{type:"fill",tabId:t.tabId}:null;case"run":return{type:"run",profile:t.profile,consent:kt(t.consent)?t.consent:{},disabledKeys:Array.isArray(t.disabledKeys)?t.disabledKeys.filter(n=>typeof n=="string"):[]};case"report":return{type:"report",filled:I(t.filled),skipped:I(t.skipped),gaps:I(t.gaps)};default:return null}}function I(e){return typeof e=="number"&&Number.isFinite(e)?e:0}function kt(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function vt(e){if(e==null)return"<none>";let t=String(e);return t.length===0?"<empty>":t.length<=2?`<${t.length} chars>`:`${t[0]}***<${t.length} chars>`}function z(e,t,n){let r=n?Ae(n):void 0;r?console.log(`[job-os-autofill:${e}] ${t}`,r):console.log(`[job-os-autofill:${e}] ${t}`)}function ve(e,t,n){let r=n?Ae(n):void 0;r?console.warn(`[job-os-autofill:${e}] ${t}`,r):console.warn(`[job-os-autofill:${e}] ${t}`)}var At=new Set(["ats","adapter","reason","key","kind","status","stage","error"]);function Ae(e){let t={};for(let[n,r]of Object.entries(e))typeof r=="string"&&!At.has(n)?t[n]=vt(r):t[n]=r;return t}var Fe="__jobOsAutofillReady",Ee=window;Ee[Fe]||(Ee[Fe]=!0,chrome.runtime.onMessage.addListener((e,t,n)=>{if(t.id!==chrome.runtime.id)return!1;let r=ke(e);return!r||r.type!=="run"?!1:(Ft(r.profile,r.consent,r.disabledKeys).then(()=>n({ok:!0})).catch(o=>{ve("content","run failed",{error:o.name}),n({ok:!1,error:o.message})}),!0)}));async function Ft(e,t,n){let r=de(e),o=W({url:new URL(location.href),document}),i=Q(o,document);z("content","form detected",{ats:o.id,fields:i.length});let l=ye(r,t),s=be({adapter:o,fields:i,values:l,consent:t,disabledKeys:new Set(n)}),d=await he(s,i);we(document,d,o.label),z("content","fill complete",{ats:o.id,filled:d.filled.length,skipped:d.skipped.length,gaps:d.requiredGaps.length}),chrome.runtime.sendMessage({type:"report",filled:d.filled.length,skipped:d.skipped.length,gaps:d.requiredGaps.length})}})();
